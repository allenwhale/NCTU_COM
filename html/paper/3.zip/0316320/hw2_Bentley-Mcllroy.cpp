#include <stdio.h>
#include <algorithm>
using namespace std;
typedef pair<int, int> PI;
int median(int a[], int m1, int m2, int m3){
	PI tmp[4];
	tmp[0] = PI(a[m1], m1);
	tmp[1] = PI(a[m2], m2);
	tmp[2] = PI(a[m3], m3);
	if(tmp[1] < tmp[0])swap(tmp[1], tmp[0]);
	if(tmp[2] < tmp[1])swap(tmp[2], tmp[1]);
	if(tmp[1] < tmp[0])swap(tmp[1], tmp[0]);
	return tmp[1].second;
}
int find_pivot(int a[], int l, int h){
	int N = h - l;
	int e1 = N / 8; 
	int e2 = N / 4;
	int mid = (l+h) / 2;
	int m1 = median(a, l, l+e1, l+e2);
	int m2 = median(a, mid-e1, mid, mid+e1);
	int m3 = median(a, mid+e1, h-1-e1, h-1);
	return median(a, m1, m2, m3);
}
int partition(int a[], int l, int h){
	int p = find_pivot(a, l, h);
	swap(a[p], a[h-1]);
	int x = a[h-1];
	int i=l;
	for(int j = l; j < h; j++){
		if(a[j] < x)
			swap(a[j], a[i++]);
	}
	swap(a[i], a[h-1]);
	return i;
}
void qsort(int a[], int l,int h){
	if(h - l <= 1)return;
	int p = partition(a, l, h);
	qsort(a, l, p);
	qsort(a, p+1, h);
}
int N, s[512010];
int main(){
	while(~scanf("%d",&N)){
		for(int i=0;i<N;i++){
			scanf("%d",&s[i]);
		}
		qsort(s,0,N);
		for(int i=0;i<N;i++){
			printf("%d%c",s[i],i==N-1?'\n':' ');
		}
	}
	return 0;
}
