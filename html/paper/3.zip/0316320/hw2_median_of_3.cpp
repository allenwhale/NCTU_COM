#include <stdio.h>
#include <algorithm>
using namespace std;
typedef pair<int, int> PI;
PI median_of_3(int a[], int l, int h){
	PI tmp[4];
	tmp[0] = PI(a[l], l);
	tmp[1] = PI(a[(l+h)/2], (l+h)/2);
	tmp[2] = PI(a[h-1], h-1);
	if(tmp[1] < tmp[0])swap(tmp[1], tmp[0]);
	if(tmp[2] < tmp[1])swap(tmp[2], tmp[1]);
	if(tmp[1] < tmp[0])swap(tmp[1], tmp[0]);
	return tmp[1];
}
int partition(int a[], int l, int h){
	PI p = median_of_3(a, l, h);
	swap(a[p.second], a[h-1]);
	int x = a[h-1];
	int i=l;
	for(int j = l; j < h; j++){
		if(a[j] < x)
			swap(a[j], a[i++]);
	}
	swap(a[i], a[h-1]);
	return i;

}
void qsort(int a[], int l,int h){
	if(h - l <= 1)return;
	int p = partition(a, l, h);
	qsort(a, l, p);
	qsort(a, p+1, h);
}
int N, s[512010];
int main(){
	while(~scanf("%d",&N)){
		for(int i=0;i<N;i++){
			scanf("%d",&s[i]);
		}
		qsort(s,0,N);
		for(int i=0;i<N;i++){
			printf("%d%c",s[i],i==N-1?'\n':' ');
		}
	}
	return 0;
}
